class QuizUser {
  final uid;
  QuizUser({this.uid});
}
