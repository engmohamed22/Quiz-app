package com.example.quiz_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
